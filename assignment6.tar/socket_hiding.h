#ifndef SOCKETHIDING_H
#define SOCKETHIDING_H

extern void hide_sockets(void);
extern void unhide_sockets(void);

#endif
