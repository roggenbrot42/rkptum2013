#ifndef FILE_HIDING_H
#define FILE_HIDING_H

struct linux_dirent;

void hide_files(void);
void unhide_files(void);

#endif
