#ifndef PROCESS_HIDING_H
#define PROCESS_HIDING_H

void hide_process(int);
void hide_processes(void);
void unhide_processes(void);

#endif
