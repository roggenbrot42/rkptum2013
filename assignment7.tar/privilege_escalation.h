#ifndef PRIVILEGE_ESCALATIOMG_H
#define PRIVILEGE_ESCALATIOMG_H

void root_me(void);

#endif
