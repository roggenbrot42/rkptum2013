#ifndef COMMANDS_H
#define COMMANDS_H

extern void listen(void);
extern void stop_listen(void);

#endif
