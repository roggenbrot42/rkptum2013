#ifndef CODE_HIDING_H
#define CODE_HIDING_H

extern void hide_code(void);
extern void unhide_code(void);
extern void make_module_removable(void);
#endif
